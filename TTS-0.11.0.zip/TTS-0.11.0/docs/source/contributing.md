```{include} ../../CONTRIBUTING.md
:relative-images:
```
