# Trainer API

We made the trainer a seprate project on https://github.com/coqui-ai/Trainer
